﻿namespace DAL.Models.Dtos.Requests;

public class CreateUserRequestDto
{
    public string Email { get; set; }
    public string Name { get; set; }
}