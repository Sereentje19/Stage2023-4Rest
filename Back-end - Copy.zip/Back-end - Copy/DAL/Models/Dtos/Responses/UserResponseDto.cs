﻿namespace DAL.Models.Dtos.Responses;

public class UserResponseDto
{
    public string Email { get; set; }
    public string Name { get; set; }
}