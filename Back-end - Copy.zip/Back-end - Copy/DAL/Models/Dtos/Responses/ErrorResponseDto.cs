﻿namespace DAL.Models.Dtos.Responses
{
    public class ErrorResponseDto
    {
        public bool Success { get; set; }
        public string Message { get; set; }
    }
}
